
//Title:        UnitTestParseHistory
//Version:      7/28/99
//Copyright:    Copyright (c) 1999 GE Marquette Medical Systems
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet

package com.mei.coro.qsdata;

import java.io.*;
import java.net.*;
import com.mei.coro.oblink.store.StripChartData;

public class UnitTestParseHistory {

    public UnitTestParseHistory() {
    }
    /**
     * For testing only.
    **/
    public static void main(String[] args) {
        ParseHistory parseHistory;
        StripChartData stripChartData=new StripChartData();
        InputStream tmpIn;
        long rightEdgeTime=System.currentTimeMillis()/1000-ParseHistory.QS_TO_JAVA_SECS-3600
                +java.util.TimeZone.getDefault().getRawOffset()/1000;
        String source=/* args.length>0 ? args[0] : */ "http://151.186.81.4:99/"
                +"Bin/QSWeb.dll?FetalData?412&true&3600" // how much time back. (use QSBin on 81.174, Bin on 81.4)
                +"&PT_IN_LK08"
                +"&"+rightEdgeTime; // time of latest
        try {
            if (source.startsWith("http")) {
                java.net.URL url=new java.net.URL(source);
                System.out.println("Connecting to: "+source);
                tmpIn=url.openStream();
            }
            else {
                tmpIn=new FileInputStream(source);
            }
            parseHistory = new ParseHistory(tmpIn,stripChartData,3600*stripChartData.SAMPLE_RATE);
            parseHistory.invokedStandalone = true;
            parseHistory.start();
            try {
                System.out.println("Waiting 60 seconds for data");
                Thread.sleep(60000);
                System.out.println("Stopping thread");
                parseHistory.halt();
                System.out.println("Waiting 3 seconds for thread to stop");
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                System.err.println("Mainline sleep interrupted!");
                e.printStackTrace();
            }
            if (parseHistory.isAlive()) {
                System.err.println("Thread did not die!");
                stripChartData.flush();
                System.exit(1);
            }
            System.out.println("UA from "+ stripChartData.uterineActivity.getOldestTime()
                                + " to "+ stripChartData.uterineActivity.getNewestTime());
        } catch (MalformedURLException e) {
            System.err.println("Malformed URL: "+source);
        } catch (FileNotFoundException e) {
            System.err.println("File "+(args.length > 0 ? args[0] : "")+" not found");
        } catch (java.io.IOException e) {
            System.err.println("IO Exception: "+source);
            e.printStackTrace();
        }
        stripChartData.flush();
    }
}