
//Title:        HexDump
//Version:      4/14/99
//Copyright:    Copyright (c) 1999
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet


package com.mei.coro.qsdata;

import java.io.*;

/**
 * Dumps data in hexadecimal and character formats.
 *
 * @author Andy Pelletier
 **/
public class HexDump extends FilterOutputStream {

    public HexDump() {
        super(System.out);
    }
    public HexDump(OutputStream out) {
        super(out);
    }

    /**
     * For testing only.
    **/
    public static void main(String[] args) {
        HexDump hexDump = new HexDump();
        hexDump.invokedStandalone = true;
        // Make an alphabet ramp
        byte alphabet[]=new byte[26];
        for (int i=0; i<26; i++) {
            alphabet[i]=(byte)(0x41+i);
        }
        // Dump it various ways.
        System.out.println("The whole alphabet");
        dump(alphabet,0,0);
        System.out.println("Skip the letter A");
        dump(alphabet,1,0);
        System.out.println("Skip A but count it");
        dump(alphabet,1,1);
        System.out.println("5 letters at a time");
        for (int i=0; i<26; i+=5) {
            dump(alphabet, i,i,5);
        }
    }
    private boolean invokedStandalone = false;

    public void write(int oneByte) throws IOException {
        byte[] oneByteArray=new byte[1];
        oneByteArray[0]=(byte)oneByte;
        dump(oneByteArray,0,0);
    }

    public void write(byte[] buffer) throws IOException {
        dump(buffer, 0, 0);
    }

    public void write(byte[] buffer, int offset, int count) {
        dump(buffer, offset, 0, count);
    }

    public static void dump(byte data[],int offset,int base, int len) {
        int i;
        for (i=0; i+16<len; i+=16) {
            System.out.println(hexDumpRow(data,offset+i,base+i,16));
        }
        if (i<len) {
            System.out.println(hexDumpRow(data,offset+i,base+i,len-i));
        }
    }

    public static void dump(byte data[],int offset,int base) {
        for (int i=0; i<data.length; i+=16) {
            System.out.println(hexDumpRow(data,offset+i,base+i,16));
        }
    }

    public static void dump(byte data[]) {
        dump(data,0,data.length);
    }

    static String hexDumpRow(byte row[],int offset, int base,int len) {
        int j;

        String rowOut=Integer.toHexString(base)+" ";
        for (j=0; j<len && j+offset<row.length; j++) {
            rowOut+=Integer.toHexString((row[j+offset]>>>4)& 0x0f);
            rowOut+=Integer.toHexString( row[j+offset]     & 0x0f);
            rowOut+=" ";
            if (j==7) {
                rowOut+=" ";
            }
        }
        for (; j<16; j++) {
            rowOut+="   ";
            if (j==7) {
                rowOut+=" ";
            }
        }
        try {
            // Assume JDK 1.1
            for (j=0; j<len && j+offset<row.length; j++) {
                int val=row[j+offset];
                if (val>=0x20 && val <127) {
                    rowOut+=new String(row,j+offset,1); // JRE 1.1
                }
                else {
                    rowOut+='.';
                }
            }
        } catch (NoSuchMethodError e) {
            // Must be JDK 1.0
            for (j=0; j<len && j+offset<row.length; j++) {
                int val=row[j+offset];
                if (val>=0x20 && val <127) {
                    rowOut+=new String(row,0,j+offset,1); // JRE 1.0
                }
                else {
                    rowOut+='.';
                }
            }
        }
        return rowOut;
    }
}