
//Title:        UnitTestParseQS
//Version:      8/11/99
//Copyright:    Copyright (c) 1999 GE Marquette Medical Systems
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet


package com.mei.coro.qsdata;

import java.io.*;
import java.net.*;
import com.mei.coro.oblink.store.StripChartData;

public class UnitTestParseQS {
    /**
     * Tests parsing of QS PMS data.
     * <p>
     * Runs from a command line.  <code>java ParseQS </code>testURL
     * <p>
     * The one argument is the URL or a file that contains data in PMS format.
    **/
    public static void main(String args[]) {
        ParseQS parseQS;
        StripChartData tmpOut;
        InputStream tmpIn;
        if (args.length<1) {
            System.err.println("Usage: java ParseQS inURL");
            return;
        }

        try {
            if (args[0].startsWith("http")) {
                URL url=new URL(args[0]);
                System.out.println("Connecting to: "+args[0]);
                //%URLConnection connection = url.openConnection();
                //%connection.setUseCaches(false);
                //%InputStream tmpIn = connection.getInputStream();
                tmpIn=url.openStream();
            }
            else {
                tmpIn=new FileInputStream(args[0]);
            }
            System.out.println("Connected");
            tmpOut=new StripChartData();
            /*old InputStream tmpIn=new FileInputStream(args[0]); */
            parseQS= new ParseQS(tmpIn,tmpOut);
            parseQS.invokedStandalone = true;
            parseQS.start();
        } catch (MalformedURLException e) {
            System.err.println("Malformed URL: "+args[0]);
            return;
        } catch (FileNotFoundException e) {
            System.err.println("File "+args[0]+" not found");
            return;
        } catch (java.io.IOException e) {
            System.err.println("IO Exception: "+args[0]);
            e.printStackTrace();
            return;
        }
        try {
            System.out.println("Waiting 30 seconds for data");
            Thread.sleep(30000);
            System.out.println("Stopping thread");
            parseQS.halt();
            System.out.println("Waiting 3 seconds for thread to stop");
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.err.println("Mainline sleep interrupted!");
            e.printStackTrace();
        }
        if (parseQS.isAlive()) {
            System.err.println("Thread did not die!");
        }
        System.out.println("UA from "+ tmpOut.uterineActivity.getOldestTime()
                            + " to "+ tmpOut.uterineActivity.getNewestTime());
    }
} 