
//Title:        HexDumpInputFilter
//Version:      4/14/99
//Copyright:    Copyright (c) 1999 GE Marquette Medical Systems
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet


package com.mei.coro.qsdata;

import java.io.FilterInputStream;
import java.io.InputStream;
import java.io.IOException;

/**
 * Dumps bytes in hex as they pass through.
**/
public class HexDumpInputFilter extends FilterInputStream {
    int byteCount;

    /**
     * Converts an input stream to dump its input as it reads.
     *
     * @param in    The data input stream.
    **/
    public HexDumpInputFilter(InputStream in) {
        super(in);
    }


// InputStream methods
    /**
     * Reads a single byte, and dumps it as it passes through.
     *
     * @return The byte read, or -1 on error.  Only the low order byte will
     *         be filled.
     *
     * @see java.io.InputStream#read()
    **/
    public int read() throws IOException {
        int tmp=in.read();
        if (tmp!= -1) {
            byte[] data=new byte[1];
            data[0]=(byte)tmp;
            HexDump.dump(data,0,byteCount);
            byteCount++;
        }
        return tmp;
    }

    /**
     * Fills an array with bytes, and dumps them.
     *
     * @param buffer Destination location.
     *
     * @return Length read, or -1 on error.
     *
     * @see java.io.InputStream#read(byte[])
    **/
    public int read(byte[] buffer) throws IOException {
        int tmp=in.read(buffer);
        if (tmp!= -1) {
            HexDump.dump(buffer,0,byteCount,tmp);
            byteCount+=tmp;
        }
        return tmp;
    }

    /**
     * Reads bytes into a buffer, and dumps them.
     *
     * @param buffer    Destination.
     * @param offset    Offset within buffer for the first byte.
     * @param count     Number of bytes to read.
     *
     * @see java.io.InputStream#read(byte[],int,int)
    **/
    public int read(byte[] buffer, int offset, int count) throws IOException {
        int tmp=in.read(buffer, offset, count);
        if (tmp!= -1) {
            HexDump.dump(buffer,offset,byteCount,tmp);
            byteCount+=tmp;
        }
        return tmp;
    }

    /**
     * Skips past some bytes.  They are not dumped.
     *
     * @param count Number of bytes to skip.
    **/
    public long skip(long count) throws IOException {
        long tmp=in.skip(count);
        byteCount+=tmp;
        return tmp;
    }
} 