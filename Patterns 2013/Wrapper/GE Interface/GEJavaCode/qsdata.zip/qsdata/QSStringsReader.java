
//Title:        QSStringsReader
//Version:      7/30/99
//Copyright:    Copyright (c) 1999 GE Marquette Medical Systems
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet


package com.mei.coro.qsdata;

import java.io.*;
import java.net.*;
import com.mei.coro.oblink.UserMessageTable;
import com.mei.coro.oblink.UserMessage;

/**
 * Loads translations in Java 1.1.
**/
public class QSStringsReader extends QSStrings {
    BufferedReader inReader=null;

    public QSStringsReader(URL documentBase,String sourceFile) {
        super(documentBase,sourceFile);
        if (inStream!=null) {
            inReader=new BufferedReader(new InputStreamReader(inStream));
        }
        else {
            inReader=null;
        }
    }

    public boolean fillTable(UserMessageTable table) {
        if (inReader==null) {
            return false;
        }
        boolean success=readAndFill(table);
        try {
            inReader.close();
        } catch (Exception e) {
        }
        inReader=null;
        inStream=null;
        return success;
    }

    private boolean readAndFill(UserMessageTable table) {
        for (;;) {
            String thisLine;
            try {
                thisLine=inReader.readLine();
            } catch (IOException e) {
                System.err.println("Could not read strings file.");
                e.printStackTrace();
                return false;
            }
            if (thisLine==null) {
                break; // End of file
            }
            storeTranslation(thisLine,table);
        }
        return true;
    }

    private boolean invokedStandalone = false;
    /**
     * For testing only.  Reads a file, parses it, and checks one translation.
    **/
    public static void main(String[] args) {
        Reader reader;
        QSStrings qsStrings = new QSStringsReader(null,"http://www/people/andyp/oblink/QSWebStrings.dat");
        qsStrings.invokedStandalone = true;
        UserMessageTable messageTable=new UserMessageTable();
        if (qsStrings.fillTable(messageTable)) {
            if ("FECG".equals(messageTable.getTranslation(5,2,"Wrong"))) {
                System.out.println("QSStrings pass!");
            }
            else {
                System.err.println("Translation failed");
            }
        }
    }
}