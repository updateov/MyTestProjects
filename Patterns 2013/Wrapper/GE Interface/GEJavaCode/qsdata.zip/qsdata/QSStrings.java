
//Title:        QSStrings
//Version:      7/30/99
//Copyright:    Copyright (c) 1999 GE Marquette Medical Systems
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet


package com.mei.coro.qsdata;

import java.io.*;
import java.net.*;
import com.mei.coro.oblink.UserMessageTable;
import com.mei.coro.oblink.UserMessage;

/**
 * Parses a file for the (translated) text strings.
**/
public class QSStrings {
    private transient int[] nums=new int[4];
    private transient String theText;
    private transient boolean parseError=false;
    private transient String parseErrorMessage=null;
    InputStream inStream=null;

    public QSStrings(URL documentBase,String sourceFile) {
        if (!openConnection(documentBase,sourceFile)) {
            System.err.println("Could not open language file");
            inStream=null;
        }
    }


    /**
     * Uses the available URL to open a connection to QS.
     * <p>
     * The inputs are <code>inURL</code> and <code>documentBase</code>.  Both
     * should not be null.  The output will be in <code>in</code>.
    **/
    private boolean openConnection(URL documentBase,String inURL) {
        inStream=null;
        try {
            URL url;
            if (inURL!=null) {
                if (documentBase!=null) {
                    url=new URL(documentBase,inURL);
                }
                else {
                    url=new URL(inURL);
                }
            }
            else if (documentBase!=null) {
                url=documentBase;
            }
            else {
                System.out.println("No language source provided.");
                return false;
            }
            URLConnection connection = url.openConnection();
            connection.setUseCaches(false);
            inStream= connection.getInputStream();
            return true;
        } catch (MalformedURLException e) {
            System.err.println("Improper URL: "+inURL);
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            System.err.println("Could not connect to "+inURL);
            e.printStackTrace();
            return false;
        }
    }

    public boolean fillTable(UserMessageTable table) {
        if (inStream==null) {
            return false;
        }
        boolean success=readAndFill(table);
        try {
            inStream.close();
        } catch (Exception e) {
        }
        inStream=null;
        return success;
    }

    private boolean readAndFill(UserMessageTable table) {
        String leftover="";
        for (;;) {
            String thisLine;
            try {
                // Read a line in Java 1.0.  Painful.
                if (inStream==null) {
                    break; // Past EOF.
                }
                thisLine=leftover;
                leftover="";
                // Read a line, one character at a time.
                for (;;) {
                    int v=inStream.read();
                    if (v==-1) {
                        // EOF
                        inStream.close();
                        inStream=null;
                        break;
                    }
                    char c=(char)v;
                    if (c=='\r') {
                        v=inStream.read();
                        if (v==-1) {
                            // EOF
                            inStream.close();
                            inStream=null;
                            break;
                        }
                        c= (char)v;
                        if (v!='\n') {
                            leftover=String.valueOf(c);
                        }
                        break;
                    }
                    else if (c=='\n') {
                        break;
                    }
                    thisLine+=c;
                }

            } catch (IOException e) {
                System.err.println("Could not read strings file.");
                e.printStackTrace();
                return false;
            }
            if (thisLine==null) {
                break; // End of file
            }
            storeTranslation(thisLine,table);
        }
        return true;
    }

    /**
     * Parses a line, and stores the translation in the table.
     *
     * @param thisLine  A non-null line of the form [nn][nn][nn]nn///text///comment
     * @param table     Destination table.
     *
     * @return False if a parsing error occurred.\
    **/
    protected boolean storeTranslation(String thisLine,UserMessageTable table) {
        if (thisLine.length()<=0 || thisLine.charAt(0)=='*') {
            parseError=false;
            return true; // Comment or empty line.
        }
        if (parseLine(thisLine)) {
            // Parse was successful. Extract important values.
            int facility=nums[0];
            int dialog=nums[1];
            int messageId=nums[2];
            int maxLen=nums[3];
            // Save the translation.
            table.setTranslation(facility,dialog,messageId,theText);
        }
        else if (parseError) {
            System.err.println("Could not parse strings file");
            System.err.println(parseErrorMessage);
            System.err.println("Offending line:");
            System.err.println(thisLine);
            return false;
        }
        return true;
    }

    /**
     * Parses a line from the strings file.  The line contains 4 numbers and
     * some text.  The first 3 numbers are in brackets.  The text is surrounded
     * with ///. Comment lines start with a "*".
    **/
    private boolean parseLine(String raw) {
        theText=null;
        parseError=true;

        if (raw.length()<=0) {
            parseError=false;
            return false;
        }
        int index=0;

        // Read four numbers.  The first three have brackets.
        for (int whichNum=0; whichNum<4; whichNum++) {
            nums[whichNum]=0;
            if (whichNum!=3) { // The fourth number has no brackets.
                if (raw.charAt(index)!='[') {
                    parseErrorMessage="Expected [, got "+raw.charAt(index);
                    return false;
                }
                index++;
            }
            while (index<raw.length()) {
                char c= raw.charAt(index);
                if (!Character.isDigit(c)) {
                    break;
                }
                nums[whichNum]=nums[whichNum]*10+Character.digit(c,10);
                index++;
            }
            if (index>=raw.length()) {
                parseErrorMessage="Premature termination";
                return false;
            }
            if (whichNum!=3) { // The fourth number has no brackets.
                if (raw.charAt(index)!=']') {
                    parseErrorMessage="Expected ], got "+raw.charAt(index);
                    return false;
                }
                index++;
            }
        }
        // Find the starting and ending triple slash
        for (int whichSlash=0; whichSlash<3; whichSlash++) {
            if (index>=raw.length()) {
                parseErrorMessage="Premature termination";
                return false;
            }
            if (raw.charAt(index)!='/') {
                parseErrorMessage="Expected /, got "+raw.charAt(index);
                return false;
            }
            index++;
        }
        int endIndex=raw.lastIndexOf("///",raw.length());
        if (endIndex<index) {
            parseErrorMessage="No terminating ///";
            return false;
        }
        theText=raw.substring(index,endIndex);
        parseError=false;
        return true;
    }

    boolean invokedStandalone = false;
}