
//Title:        ParseHistory
//Version:      8/23/99
//Copyright:    Copyright (c) 1999 GE Marquette Medical Systems
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet


package com.mei.coro.qsdata;

import java.io.*;
import java.net.*;
import com.mei.coro.oblink.store.StripChartData;
import com.mei.coro.oblink.store.HrMode;
import com.mei.coro.oblink.store.UaMode;
import com.mei.coro.qsdata.BadQSFormatException;


/**
 * Reads historical data from the QS PtData area. The data formats for the wave
 * and status are the same as PMS (in ParseQS), but the headers are different.
**/
public class ParseHistory extends ParseQS {
    private final long maxT;

    // QS Definitions
    private static final int MAX_IMAGE=32768;
    private static final int MAX_PT_DATA_CHAR=9;

    // Patient Data (PT_DATA)
    private static final int TIME_OFFSET            =0;
    private static final int HUNDREDTHS_OFFSET      =4;
    private static final int PROG_ID_OFFSET         =5;
    private static final int WS_NUMBER_OFFSET       =6;
    private static final int DISPLAY_TIME_OFFSET    =8;
    private static final int ITEM_OFFSET            =12;
    private static final int CLASS_OFFSET           =14;
    private static final int PT_DATA_TAG_SET_OFFSET =16;
    private static final int MODIFY_TIME_OFFSET     =18;
    private static final int MODIFY_ID_OFFSET       =22;
    private static final int NUMBER_OFFSET          =24;
    private static final int CHAR_DATA_OFFSET       =32;
    private static final int LC_IMAGE_LEN_OFFSET    =CHAR_DATA_OFFSET+MAX_PT_DATA_CHAR;
    private static final int PT_DATA_LENGTH         =LC_IMAGE_LEN_OFFSET+4;
    private byte[] ptHeaderBuf=new byte[PT_DATA_LENGTH];
    private int displayTime;
    private int lcImageLen;

    // Tag (PT_DATA_TAG)
    private static final int CARRIED_FORWARD            =0x0001;
    private static final int CORRECTED_DATA             =0x0002;
    private static final int DATA_WHICH_MAY_BE_VALIDATED=0x0004;
    private static final int MONITOR_DATA_NORMAL        =0x0008;
    private static final int MONITOR_DATA_ALARMS_OFF    =0x0010;
    private static final int MONITOR_DATA_ALARM         =0x0020;
    private static final int NUMBER_VALID               =0x0040;
    private static final int VALIDATED_DATA             =0x0080;
    private static final int DEFAULT_VALUE              =0x0100;
    private static final int LAB_PRELIMINATRY           =0x0200;
    private static final int LAB_FINAL                  =0x0400;
    private static final int LAB_CORRECTION             =0x0800;
    private static final int LAB_PENDING                =0x1000;
    private static final int INSTANCE                   =0x2000;
    private static final int UNUSED14                   =0x4000;
    private static final int UNUSED15                   =0x8000;

    // Image Data Header  (IMAGE_DATA_HEADER), follows PT_DATA
    private static final int E_TYPE_OFFSET=0;               // eType (see below)
    private static final int LENGTH_OFFSET=1;               // lLength
    private static final int OLD_MODIFY_TIME_OFFSET=5;      // lOldModifyTime
    private static final int OLD_MODIFY_ID_OFFSET=9;        // lOldModifyTime
    private static final int IMAGE_DATA_HEADER_LENGTH=11;
    private byte[] imageDataHeader=new byte[IMAGE_DATA_HEADER_LENGTH];
    private int eType;
    private int lLength;

    // Image types (eType values)
    private static final int ERROR_IMAGE        =0;
    private static final int CHANGE_TAG_IMAGE   =1;
    private static final int ALPHA_IMAGE        =2;
    private static final int MULTI_IMAGE        =3;
    private static final int FLUID_IMAGE        =4;
    private static final int FWAVE_IMAGE        =5;         // rWAVE_DATA
    private static final int FMSTAT_IMAGE       =6;        // rFMSTAT
    private static final int HISTORY_IMAGE      =7;
    private static final int ECG12SL_IMAGE      =8;
    private static final int CHOICE_IMAGE       =9;
    private static final int ORDER_IMAGE        =10;
    private static final int INSTANCE_IMAGE     =11;
    private static final int MULIVALUE_IMAGE    =12;

    // Image data trailer.
    private static final int IMAGE_DATA_TRAILER_LENGTH=3;

    /**
     * Constructs a new history connection from an open data stream.  The caller
     * must remember to start the thread.
     *
     * @param in        The input stream.
     * @param theData   Where to store the data.
     * @param maxT      Largest time expected.  As status data comes in, it has
     *                  a start time, but not a stop time.  This value acts as
     *                  the end time for incoming status.  The time must be in
     *                  StripChartData time units, that is quarter seconds since
     *                  Jan 1970.
    **/
    public ParseHistory(InputStream in, StripChartData theData, long maxT) {
        super(in,theData);
        this.maxT=maxT;
    }

    /**
     * Constructor for use with applets.
     *
     * @param documentBase Context where to find the data.  In an applet, this
     *                      is often where the applet's document came from.  Applets
     *                      can fill this with Applet.getDocumentBase().
     * @param inURL Source connection to the data.  An example might be
     *              <code>"http://www.qshost.com/qsdata.dll?patientId=1234"</code>
     * @param out   Destination for the data.
     * @param maxT      Largest time expected.  As status data comes in, it has
     *                  a start time, but not a stop time.  This value acts as
     *                  the end time for incoming status.  The time must be in
     *                  StripChartData time units, that is quarter seconds since
     *                  Jan 1970.
     *
     * @see java.applet.Applet#getDocumentBase()
    **/
    public ParseHistory(URL documentBase, String inURL, StripChartData out, long maxT,boolean delay) {
        super(documentBase,inURL,out,delay,"ReceiveQSHistory");
        this.maxT=maxT;
    }

    /**
     * Overrides the ParseQS method so it does not modify sourceStatus.
    **/
    void init() {
        if (in==null && documentBase==null && inURL==null) {
            setSourceStatus(3,0,"No source provided.");
            terminate=true;
        }
        else {
            setSourceStatus(3,2,"Data collection has not started");
        }
        super.setDaemon(true);
	}

    /**
     * Thread loop. Reads all data until an error, eof, or told to stop.  Use
     * the Thread.start() method instead of calling this routine directly.
     * <p>
     * Now that <code>Thread.stop()</code> is deprecated, use the <code>halt()</code>
     * method to terminate the thread.
     *
     * @see ParseQS#halt()
     * @see java.lang.Thread#stop()
    **/
    public void run() {
        if (terminate) {
            return;
        }
        if (in==null) {
            openConnection();
            if (in==null) {
                // Some failure. See sourceStatus and java console for details
                return;
            }
        }
        else {
            setSourceStatus(3,12,"Requesting data from QS.");
        }
        if (CLOSE_DEBUG) {
            System.out.println("History connection to QS open");
        }
        while (!Thread.currentThread().isInterrupted() && !terminate) {
            try {
                readPtDataRecord();
            } catch (InterruptedIOException e) {
                // This thread would continue forever unless someone
                // interrupted it.  Interupted IO is the normal exit.
                if (terminate) {
                    break;
                }
                setSourceStatus(3,13,"The connection to QS was interrupted.");
                e.printStackTrace();
            } catch (IOException e) {
                // On the Sun, the interrupted IO comes up as a
                // SocketException, with text "Interrupted system call".
                if (terminate) {
                    break;
                }
                setSourceStatus(3,14,"The connection to QS failed unexpectedly.");
                e.printStackTrace();
                break;
            } catch (OutOfDataException e) {
                // The server closed the connection.
                setSourceStatus(3,15,"QS closed the connection.");
                break;
            } catch (BadQSFormatException e) {
                setSourceStatus(3,17,"Corrupt history data from QS.");
                e.printStackTrace();
                break;
            }

            if (invokedStandalone) {
                if (lcImageLen>=IMAGE_DATA_HEADER_LENGTH && eType==FWAVE_IMAGE) {
                    System.out.println("Wave record, time="+displayTime
                                +" length="+this.lcImageLen );
                }
                else if (lcImageLen>=IMAGE_DATA_HEADER_LENGTH && eType==FMSTAT_IMAGE) {
                    System.out.println("Status record, time="+displayTime
                                +" length="+this.lcImageLen );
                }
                else {
                    System.out.println("Read record, time="+displayTime
                                +" length="+this.lcImageLen
                                +" eType="+eType );
                }
            }
            startTime=convertTimeUnits(displayTime);

            try {
                storeStatusData(Math.max(1,maxT-startTime));
                if (hasWave) {
                    // Since we receive all the status in bulk, get the status
                    // for the wave data we just got.  Luckily status comes before
                    // wave, and the status for the entire wave packet will be the same.
                    HrMode hr2Mode=(HrMode)this.stripChartData.hr2Modes.getValueAt(startTime);
                    if (hr2Mode==null) {
                        // I did not get modes before data.  Do I swap or not? Punt!
                        throw (new BadQSFormatException("No mode information at "+displayTime));
                    }
                    boolean swapHrs= !hr2Mode.isMaternal();
                    storeWaveData(lLength,swapHrs);
                }
            } catch (BadQSFormatException e) {
                setSourceStatus(3,17,"Corrupt history data from QS.");
                e.printStackTrace();
                break;
            }
            setSourceStatus();
        }  // forever (while not interrupted)
        if (terminate) {
            setSourceStatus(3,18,"Closing the connection to QS.");
        }
        if (DEBUG) {
            System.out.println("ParseHistory terminated normally");
        }
        try {
            if (CLOSE_DEBUG) {
                System.out.println("Closing connection to PDATS");
            }
            in.close();
            if (CLOSE_DEBUG) {
                System.out.println("Connection to PDATS closed.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (terminate) {
            setSourceStatus(3,19,"Connection to QS closed.");
        }
    }

    /**
     * Reads in a single PT_DATA record, with its header and image.
    **/
    private void readPtDataRecord() throws IOException,OutOfDataException,BadQSFormatException {
        getPtDataHeader();
        if (lcImageLen==0) {
            return;
        }
        if (lcImageLen<imageDataHeader.length) {
            throw new BadQSFormatException("Image length "+lcImageLen+" too small");
        }
        if (lcImageLen>MAX_IMAGE) {
            throw new BadQSFormatException("Image length "+lcImageLen+" too large");
        }
        getImageHeader();
        if (lLength+IMAGE_DATA_HEADER_LENGTH+IMAGE_DATA_TRAILER_LENGTH!=lcImageLen) {
            throw new BadQSFormatException("Image length "+lcImageLen+" is not "+lLength+14);
        }
        getImageData();
        skipIn(IMAGE_DATA_TRAILER_LENGTH); // Ignore the trailer.
    }

    /**
     * Reads the PT_DATA header, and extracts the fields used.  The fields extracted
     * are <code>cdisplay_time,</code> and <code>lcImageLen</code>.
    **/
    private void getPtDataHeader() throws IOException,OutOfDataException {
        // Read from sequence through lcLength
        readIn(ptHeaderBuf, ptHeaderBuf.length);

        if (webServerError(ptHeaderBuf)) {
            throw new IOException("Web server error");
        }

        // Extract the fields we need.
        displayTime=getInteger32(ptHeaderBuf,DISPLAY_TIME_OFFSET);
        lcImageLen=getCardinal16(ptHeaderBuf,LC_IMAGE_LEN_OFFSET);
        if (DEBUG) {
            System.out.println("displayTime="+displayTime+" lcImageLen="+lcImageLen);
        }
    }

    /**
     * Reads the image data header.  It sits between the PT_DATA header and the
     * actual data.  It contains two fields of interest: eType and lLength.
     * The eType field tells us what kind of data to expect next.  The lLength
     * field is really a duplicate of lcImageLen, with a fixed difference of 14.
    **/
    private void getImageHeader() throws IOException,OutOfDataException {
        // Read the entire header.
        readIn(imageDataHeader, imageDataHeader.length);

        // Extract the fields we use.
        eType=getEnum8(imageDataHeader,E_TYPE_OFFSET);
        lLength=getInteger32(imageDataHeader,LENGTH_OFFSET);
    }


    /**
     * Reads the image data.  Only FWAVE_IMAGE and FMSTAT_IMAGE data will actually
     * be read.  Any other data will be skipped.
     * <p>
     * The length comes from the lLength field.
    **/
    private void getImageData() throws IOException,OutOfDataException,BadQSFormatException {
        switch (eType) {
            case FWAVE_IMAGE:
                getWaveData(lLength);
                hasWave=true;
                break;
            case FMSTAT_IMAGE:
                if (lLength!=FM_STATUS_SIZE) {
                    throw new BadQSFormatException("FMStat length is "+lLength
                                        +", but should be "+FM_STATUS_SIZE+".");
                }
                getFMStatus();
                hasStatus=true;
                break;
            case ALPHA_IMAGE:
                // Skip the whole image
                skipIn(lLength);
                break;
            default:
                System.err.println("Unexpected eType "+eType+" ignored");
                // Skip the whole image
                skipIn(lLength);
                break;
        }
    }


    boolean invokedStandalone = false;

}