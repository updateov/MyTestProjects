package com.mei.coro.qsdata;

//Title:        ParseQS
//Version:      9/24/99
//Copyright:    Copyright (c) 1999
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet

import java.io.*;
import java.net.*;
import com.mei.coro.oblink.store.*;
import com.mei.coro.qsdata.HexDumpInputFilter;
import com.mei.coro.oblink.UserMessageTable;
import com.mei.coro.qsdata.BadQSFormatException;

/**
 * Parse fetal heart data from a PMS format input stream, and store it.  PMS
 * is the name of a server in QMI's QS product.
 * <p>
 * The data extracted are primarily the heart rates and uterine pressures, which
 * are both sampled at quarter second intervals.  Monitoring modes and other
 * "status" information is included in the data stream as it changes.
 * <p>
 * The data format consists of chunks of time, usually a minute each.  Each
 * chunk has a wave record and an optional status record.  Each record consists
 * of a header followed by record-type dependent data.  For wave data, this is
 * a wave header and a number of waves.  Each wave begins with a mini-header,
 * followed by the samples.
 * <p>
 * <UL>
 * <LI> Data stream, consisting of: <UL>
 * <LI>     Chunks of time (1-60 seconds), which can have (in any order)
 * <LI>     An optional status record
 * <LI>     A wave data record, which contains <UL>
 * <LI>         A record header
 * <LI>         A wave header, containing <UL>
 * <LI>             Spectra Alert information, ignored here
 * <LI>             Length of the wave data
 * <LI>             Up to 4 waves (HR1, HR2, MHR, and UA), each of which with <UL>
 * <LI>                 Wave data header
 * <LI>                 Between 8 and 240 Samples of data <UL>
 * <LI>                     Each sample is a byte. HRs are in BPM. UA in mmHg.
 * <LI>                     Each sample represents one quarter second.
 *                      </UL>
 *                  </UL>
 *              </UL>
 *          </UL>
 * <LI>     A PMS return code.
 *      </UL>
 * </UL>
 *
 * <p>
 * The first packet will be a status packet.  The time in the status packet is
 * the time of the last status change.  If it were stored with its time, it would
 * make the user think we had hours of data, when all we have is 50 minutes.  Thus
 * I delay processing the first status packet until the second packet comes in.  The
 * time used to process will be the time of the second packet.
 * <p>
 * CAUTION: <br>
 * </b>
 * The thread created here will continue reading forever.  You MUST
 * call <code>halt()</code> method to terminate.
 *
 * <p>
 * NOTE: Heart rate 1 and heart rate 2 are swapped here, unless HR2 is MECG.  QS
 * uses HR2 for the primary heart rate.  We switch the primary (back) to HR1 here.
 * (The QS reasoning dates back to Corolan and Monarch.)
 *
 * @author Andrew Pelletier
 * @version July 30,1999
**/

public class ParseQS extends Thread {
    // Debug controls.  All these should be false in production (except FUDGE_...)
                 boolean DEBUG                   =false;
    static final boolean TIME_DEBUG              =false;
    static final boolean MONITOR_OFF_DEBUG       =false;
    static final boolean MODE_DEBUG              =false;
    static final boolean STATUS_DEBUG            =false;
    private static final boolean RETURN_CODE_DEBUG       =false;
    static final boolean CLOSE_DEBUG             =false; // Help find Microsoft IE 4.0 bug: Java 1.1
    private static final boolean FUDGE_RETURN_CODE_TIME  =true; // QS simply sends the wrong time!

    static final int SAMPLES_PER_SECOND=StripChartData.SAMPLE_RATE;
    static final long QS_TO_JAVA_SECS=(365*(1976-1970)+1-1)*24*60*60; // QS use Dec 31, 1975, Java uses Jan 1, 1970
    static final long QS_TO_JAVA_MILLIS=QS_TO_JAVA_SECS*1000;
    static final long QS_TO_JAVA_SAMPLES=QS_TO_JAVA_SECS*SAMPLES_PER_SECOND;

    // Status of the connection
    private String sourceStatus1="Initializing";
    private String sourceStatus2=null; // When the status has content, this is the content.
    private String sourceStatus3=null;
    private int dialog=3;
    private int messageID=30;
    private boolean hasContent=false;
    private boolean patientIDChanged=false;
    private boolean hasSourceStatus=true;

// Local variables
    InputStream in;
    StripChartData stripChartData;
    boolean terminate=false;
    long startTime;
    private boolean caughtUp=false; // Has PMS sent the Caught Up to real time return code?
    final URL documentBase; // When used from an applet.
    final String inURL;
    boolean invokedStandalone = false;

// Incoming data format
    // The header.
    private static final int BED_ID_OFFSET=2;
    private static final int TIME_OFFSET=8;
    private static final int EDATA_OFFSET=12;
    private static final int HEADER_LENGTH=13;

    private final int FM_NOTE_LIMIT=5000;
    
    private byte[] headerBuf=new byte[HEADER_LENGTH];
    private int cBedId;
    private int liTime;
    private int eData; // The type of the data beyond the header.
    private int lastEData=Integer.MAX_VALUE; // Debug only: eData from the previous packet to diagnose loss of sync.

    // eData options
    private static final int PMS_ECG12SL=0;
    private static final int PMS_FM_NOTE=1;
    private static final int PMS_STATUS=2;
    private static final int PMS_HISTORY_EVENT=3;
    private static final int PMS_PARAMETER_DATA=4;
    private static final int PMS_PATIENT_ID=5;
    private static final int PMS_STORE_CHUNK=6;
    private static final int PMS_WAVE_DATA=7;
    private static final int PMS_RETURN_CODE=14;

    // WAVE_DATA header
    private static final int DATA_LEN_OFFSET=30; // Into waveHeader
    private static final int WAVE_HEADER_LENGTH=32;
    private byte waveHeader[]=new byte[WAVE_HEADER_LENGTH];
    private int cDataLen;

    // WAVE_DATA content (_rWaveData)
    static final int TYPE_OFFSET=0;
    static final int NUM_SAMPLES_OFFSET=1;
    static final int F_WAVE_CHUNK_OFFSET=3;
    static final int MAXIMUM_NUM_SAMPLES=240;
    static final int MAXIMUM_R_WAVE_DATA=F_WAVE_CHUNK_OFFSET+MAXIMUM_NUM_SAMPLES;
    byte waveData[]=new byte[MAXIMUM_R_WAVE_DATA*N_WAVES];
    transient boolean hasWave=false;

    // WAVE_DATA types (at TYPE_OFFSET)
    static final int WAVE_FHR1=0;
    static final int WAVE_FHR2=1;
    static final int WAVE_MHR =2;
    static final int WAVE_UA  =3;
    static final int N_WAVES  =4;
    // Penlift values for the waves.  Note: These are the QS values. They may
    // differ from the values used internally.  The switch is made in storeWaveData
    // below, as needed.
    static final byte HR_PENLIFT=0;
    static final byte UA_PENLIFT=(byte)0x80;

    // FM_STATUS content (_rFmStat)
    static final int STAT_SET=0;
    static final int CHART_SPEED=1;
    static final int DEVICE_TYPE=2;
    static final int HR1_MODE=3;
    static final int HR2_MODE=4;
    static final int HR3_MODE=5;
    static final int SAMPLE_RATE=6;
    static final int SP_DATA=7;
    static final int UA_MODE=8;
    static final int FM_STATUS_SIZE=9;
    byte fmStatus[]=new byte[FM_STATUS_SIZE];
    boolean hasStatus=false;
    boolean neverHadStatus=true;
    boolean firstMessage=true; // The time in the first (status) message is wacky.
    boolean swapHeartRates=true; // Switch HR1 and HR2 unless MECG on HR2

    // STAT_SET bits
    static final int FM_STAT_BUFFER_OVERFLOW=0x01;
    static final int FM_STAT_POWER_OFF=0x02;
    static final int FM_STAT_POWER_ON=0x04;
    static final int FM_STAT_MATERNAL_ONLY_MODE=0x08;

    // Mode values (HR1_MODE, HR2_MODE, HR3_MODE, UA_MODE)
    static final int FM_STAT_MODE_UNDEFINED =0;
    static final int FM_STAT_MODE_EXT       =1;
    static final int FM_STAT_MODE_FECG      =2;
    static final int FM_STAT_MODE_INOP      =3;
    static final int FM_STAT_MODE_IUP       =4;
    static final int FM_STAT_MODE_MECG      =5;
    static final int FM_STAT_MODE_TOCO      =6;
    static final int FM_STAT_MODE_OFF       =7;
    static final int FM_STAT_MODE_NO_TRANS  =8;
    static final int FM_STAT_MODE_EXT_MHR   =9;
    static final int FM_STAT_MODE_PHONO     =10;
    static final int FM_STAT_MODE_AECG      =11;
    static final int FM_STAT_MODE_MAECG     =12;
    static final int FM_STAT_MODE_UNKNOWN   =13;

    // SP_DATA bits
    static final int FM_STAT_SP_DATA_BP             =0x01;
    static final int FM_STAT_SP_DATA_FAST           =0x02;
    static final int FM_STAT_SP_DATA_MARK           =0x04;
    static final int FM_STAT_SP_DATA_OFF_SCALE      =0x08;
    static final int FM_STAT_SP_DATA_SPO2           =0x10;
    static final int FM_STAT_SP_DATA_TEST_BUTTON    =0x20;
    static final int FM_STAT_SP_DATA_SPECTRA_RESET  =0x40;
    static final int FM_STAT_SP_DATA_SPECTRA_ERROR  =0x80;

    // Return Codes
    private static final int C_NORMAL       =10001;
    private static final int C_ALL_DATA     =19002; // Caught up to real time.
    private static final int C_CONNECTING   =19003; // QS in blue screen "Getting data"
    private static final int C_CONNECT_ERROR=19004;
    private static final int C_NO_DATA      =19005; // No data available at this time.
    private static final int C_NOT_CONNECTED=19006;
    private static final int C_POWER_OFF    =19007; // Fetal monitor has been powered off.
    private static final int C_PT_ID_CHANGE =19008; // Probable new patient.
    private int returnCode=0;
    private boolean hasReturnCode=false;
    private boolean monitorIsOff=true;

    /**
     * Create a thread that will parse fetal heart data from a QS system.
     * <p>
     * Typical usage is
     * <code>
     *      URL url=new URL("http://qs.hospital.org/pmsdata");
     *      URLConnection connection = url.openConnection();
     *      connection.setUseCaches(false); // Covers variety of browser defaults
     *      InputStream dataStream =connection.getInputStream();
     *      tr=new ParseQS(dataStream);
     *      tr.start();
     *      ...
     *      // Do not want any more data
     *      tr.halt();
     * </code>
     */
    public ParseQS(InputStream in, StripChartData out) {
        super("ReceiveQSRealTime");
        this.in= DEBUG ? new HexDumpInputFilter(in) : in;
        this.stripChartData=out;
        this.inURL=null;
        this.documentBase=null;
        init();
    }

    /**
     * Constructor that allows debug of the incoming data.  This constructor is
     * not usually used for production purposes.
     *
     * @param debug When true, the incoming bytes will be dumped to System.out.
     *
     * @see HexDumpInputFilter
    **/
    public ParseQS(InputStream in, StripChartData out, boolean debug) {
        this.DEBUG=debug;
        this.in= DEBUG ? new HexDumpInputFilter(in) : in;
        this.stripChartData=out;
        this.inURL=null;
        this.documentBase=null;
        init();
    }

    /**
     * Constructor for use with applets.
     *
     * @param documentBase Context where to find the data.  In an applet, this
     *                      is often where the applet's document came from.  Applets
     *                      can fill this with Applet.getDocumentBase().
     * @param inURL Source connection to the data.  An example might be
     *              <code>"http://www.qshost.com/qsdata.dll?patientId=1234"</code>
     * @param out   Destination for the data.
     *
     * @see java.applet.Applet#getDocumentBase()
    **/
    public ParseQS(URL documentBase, String inURL, StripChartData out,boolean delayOpen) {
        super("ReceiveQSRealTime");
        this.documentBase=documentBase;
        this.inURL=inURL;
        this.stripChartData=out;
        init();
        if (!delayOpen) {
            openConnection();
            if (in==null) {
                // Open failed. Make sure the thread does nothing.
                terminate=true;
            }
        }

    }

    /**
     * Constructor for use with subclasses names the thread.  This is the constructor
     * used by ParseHistory().
     *
     * @param documentBase Context where to find the data.  In an applet, this
     *                      is often where the applet's document came from.  Applets
     *                      can fill this with Applet.getDocumentBase().
     * @param inURL Source connection to the data.  An example might be
     *              <code>"http://www.qshost.com/qsdata.dll?patientId=1234"</code>
     * @param out   Destination for the data.
     *
     * @see java.applet.Applet#getDocumentBase()
    **/
    public ParseQS(URL documentBase, String inURL, StripChartData out,boolean delayOpen, String name) {
        super(name);
        this.documentBase=documentBase;
        this.inURL=inURL;
        this.stripChartData=out;
        init();
        if (!delayOpen) {
            openConnection();
            if (in==null) {
                // Open failed. Make sure the thread does nothing.
                terminate=true;
            }
        }

    }

    /**
     * Create a thread that will parse fetal heart data from a QS system.
     * <p>
     * NOTE: I had a security violation running this from an applet.
     * It seems that you need to <code>new URL(getDocumentBase(),"http://..") </code>
     * at the applet level.
     *
     * @param inURL Source connection to the data.  An example might be
     *              <code>"http://www.qshost.com/qsdata.dll?patientId=1234"</code>
     * @param out   Destination for the data.
    **/
    public ParseQS(String inURL, StripChartData out) {
        super("ReceiveQSRealTime");
        this.inURL=inURL;
        this.stripChartData=out;
        this.documentBase=null;
        init();
    }

    /**
     * Create a thread that will parse fetal heart data from a QS system.
     * <p>
     * NOTE: To avoid a security violation running this from an applet,
     * use <code>inUrl=new URL(getDocumentBase(),) </code>
     * at the applet level.
     *
     * @param inURL Connection where the data comes from.
     * @param out   Where the data should be stored.
    **/
    public ParseQS(URL inURL, StripChartData out) throws IOException {
        try {
            URLConnection connection = inURL.openConnection();
            connection.setUseCaches(false);
            this.in= DEBUG ? new HexDumpInputFilter(connection.getInputStream())
                                                  : connection.getInputStream();
        } catch (IOException e) {
            setSourceStatus(3,10,"Could not connect to ",inURL,"");
            throw e;
        }
        this.inURL=null;
        this.stripChartData=out;
        this.documentBase=inURL;
        init();
    }

    void init() {
        if (in==null && documentBase==null && inURL==null) {
            setSourceStatus(3,0,"No source provided.");
        }
        else {
            setSourceStatus(3,2,"Data collection has not started");
        }
        super.setDaemon(true);
	}

    /**
     * Uses the available URL to open a connection to QS.
     * <p>
     * The inputs are <code>inURL</code> and <code>documentBase</code>.  Both
     * should not be null.  The output will be in <code>in</code>.
    **/
    void openConnection() {
        in=null;
        try {
            URL url;
            if (inURL!=null) {
                setSourceStatus(3,3,"Connecting to QS");
                if (documentBase!=null) {
                    url=new URL(documentBase,inURL);
                }
                else {
                    url=new URL(inURL);
                }
            }
            else if (documentBase!=null) {
                url=documentBase;
            }
            else {
                setSourceStatus(3,1,"No QS source provided.");
                terminate=true;
                return;
            }
            setSourceStatus(3,4,"Connecting to ",url.getHost(),"");
            URLConnection connection = url.openConnection();
            connection.setUseCaches(false);
            this.in= DEBUG ? new HexDumpInputFilter(connection.getInputStream())
                                                          : connection.getInputStream();
            setSourceStatus(3,6,"Waiting for data from ",url,"");
        } catch (MalformedURLException e) {
            setSourceStatus(3,8,"Improper URL: ",inURL,"");
            e.printStackTrace();
            terminate=true;
            return;
        } catch (IOException e) {
            setSourceStatus(3,10,"Could not connect to ",inURL,"");
            e.printStackTrace();
            terminate=true;
            return;
        }
    }

    /**
     * Thread loop. Reads all data until an error, eof, or told to stop.  Use
     * the Thread.start() method instead of calling this routine directly.
     * <p>
     * Now that <code>Thread.stop()</code> is deprecated, use the <code>halt()</code>
     * method to terminate the thread.
     *
     * @see #halt()
     * @see java.lang.Thread#stop()
    **/
    public void run() {
        if (terminate) {
            return;
        }
        if (in==null) {
            openConnection();
            if (in==null) {
                // Some failure. See sourceStatus and java console for details
                return;
            }
        }
        else {
            setSourceStatus(3,12,"Requesting data from QS.");
        }
        if (CLOSE_DEBUG) {
            System.out.println("Real time connection to QS open");
        }
        while (!Thread.currentThread().isInterrupted() && !terminate) {
            try {
                readPMSRecord();
            } catch (InterruptedIOException e) {
                // This thread would continue forever unless someone
                // interrupted it.  Interupted IO is the normal exit.
                if (terminate) {
                    break;
                }
                setSourceStatus(3,13,"The connection to QS was interrupted.");
                e.printStackTrace();
            } catch (IOException e) {
                // On the Sun, the interrupted IO comes up as a
                // SocketException, with text "Interrupted system call".
                if (terminate) {
                    break;
                }
                setSourceStatus(3,14,"The connection to QS failed unexpectedly.");
                e.printStackTrace();
                break;
            }
            catch (OutOfDataException e) {
                // The server closed the connection.
                setSourceStatus(3,15,"QS closed the connection.");
                break;
            }

            startTime=convertTimeUnits(liTime);

            if (TIME_DEBUG && (isCaughtUp() || hasReturnCode && returnCode==C_ALL_DATA)) { //% Debug
                String msg=liTime+" "+startTime/4+" "+stripChartData.getNewestTime()/4+" ";
                msg+= hasReturnCode ? "Return code " : "";
                msg+= hasStatus ? "Status " : "";
                msg+= hasWave   ? "Wave " : "";
                if (isCaughtUp() && startTime+12<stripChartData.getNewestTime()) {
                    System.out.println( "Time working backwards! "
                            + " delta "+(startTime-stripChartData.getNewestTime())/4 );
                }
                else if (isCaughtUp() && startTime>stripChartData.getNewestTime()+8) {
                    System.out.println( "Big time jump! "
                            +(startTime-stripChartData.getNewestTime())/4 );
                }
            }

            storeReturnCode();
            if (firstMessage && hasStatus && neverHadStatus) {
                // The very first message we received is status.  The time in
                // the message represents the last status change, and will be
                // inconsistent with the rest of the data.  Save it, and store
                // it with the first real data.
                firstMessage=false;
                setSourceStatus(3,16,"Established connection to QS.");
                continue;
            }
            else if (hasStatus && neverHadStatus) {
                // This is the second message.  The first one was status.  Now
                // we are getting data.  We have no error message to report.
                // Unfortunately, there is a tiny window before we store the
                // the data.
                setSourceStatus();
            }
            else if (hasWave && hasSourceStatus) {
                // Whatever was wrong is now fixed. Could have been a PMS to
                // monitor error that fixed itself.
                if (TIME_DEBUG || RETURN_CODE_DEBUG) {
                    System.out.println("QS communication working. Data time="+liTime+"="+startTime); //% Debug.
                }
                setSourceStatus();
            }

            try {
                storeStatusData(stripChartData.SAMPLE_RATE);
                if (hasWave && monitorIsOff) {
                    // Since we have wave data, the monitor must be on now.
                    // We do this because a return code might have signaled Off,
                    // and we need to cancel that condition.
                    monitorIsOff=false;
                    setSourceStatus();
                    stripChartData.storeMonitorOff(startTime,stripChartData.SAMPLE_RATE,false);
                }
                storeWaveData(cDataLen,swapHeartRates);
            } catch (BadQSFormatException e) {
                setSourceStatus(3,17,"Corrupt data from QS.");
                e.printStackTrace();
                break;
            }
        }  // forever (while not interrupted)
        if (terminate) {
            setSourceStatus(3,18,"Closing the connection to QS.");
        }
        if (DEBUG) {
            System.out.println("ParseQS terminated normally");
        }
        try {
            if (CLOSE_DEBUG) {
                System.out.println("Closing connection to PMS");
            }
            in.close();
            if (CLOSE_DEBUG) {
                System.out.println("Connection to PMS closed.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (terminate) {
            setSourceStatus(3,19,"Connection to QS closed.");
        }
    }

    /**
     * Terminate receiving data.  Applets <bold>must</bold> call this routine,
     * or the receiving thread will continue after the user has not only left
     * the page, but quit the browser!
    **/
    public void halt() {
        terminate=true;
        try {
            this.interrupt(); // May be ignored in a browser because of security restrictions.
        } catch (SecurityException e) {
            // Netscape 4.5 (maybe others) generates a security exception, which
            // prevents further termination processing, possibly including
            // preventing other threads from terminating.
            // Ignore it.  The next time data comes in, the run loop will see
            // the terminate flag and quit anyway.
        }
        //% I'd like to try in.close() here, but I am afraid the close might
        // wait for the read to finish, which may take a long time when the server
        // or connection is down.
    }

    /**
     * Read a single PMS record, and store the data.
     */
    private void readPMSRecord() throws IOException,OutOfDataException {
        cDataLen=0;
        lastEData=eData;
        // Read the header in front of all the data
        getPMSHeader();
        // What data type is it? Read the data for that type.
        switch (eData) {
            case PMS_WAVE_DATA:
                if (DEBUG) {
                    System.out.println("PMS Wave Data");
                }
                getPMSWaveHeader();
                getWaveData(cDataLen);
                hasWave=true;
                break;
            case PMS_STATUS:
                if (DEBUG) {
                    System.out.println("PMS Status");
                }
                getFMStatus();
                hasStatus=true;
                break;
            case PMS_FM_NOTE:
                if (DEBUG) {
                    System.out.println("PMS FM Note");
                }
                skipIn(FM_NOTE_LIMIT+1); // Skip the QSString
                break;
            case PMS_RETURN_CODE:
                byte[] buf=new byte[2];
                readIn(buf,buf.length);
                returnCode=this.getCardinal16(buf,0);
                hasReturnCode=true;
                break;
            //% Parse more eData types?
            default:
                // I have seen a case during development where instead of the
                // packet was the string
                // "HTTP:/1.1 500 Internal Server Error<cr><lf>
                //  Server: Microsoft-IIS/4.0<cr><lf>..."
                // Since I am fearful this may happen in the real world, I'll check
                // for that case. If we get here (which should never happen), and the
                // beginning coincides, it must be that crazy message.
                if (!webServerError(headerBuf)) {
                    System.err.println("Unknown PMS eData: "+eData);
                    String bufBytes="";
                    for (int i=0; i<headerBuf.length; i++) {
                        bufBytes+=" "+(int)headerBuf[i];
                    }
                    System.out.println("Header buf="+bufBytes);
                    System.out.println("Previous eData="+lastEData);
                }
                break;
        }
    }

    /**
     * Applies the PMS return code, usually to generate an error message.
    **/
    private void storeReturnCode() {
        if (!hasReturnCode) {
            return;
        }
        hasReturnCode=false;
        if (RETURN_CODE_DEBUG) {  //% Debug
            System.out.println("ParseQS: Return code "+returnCode+" at "+liTime+" "+startTime/4);
        }
        switch (returnCode) {
            case C_NORMAL:
                setSourceStatus();
                break;
            case C_NO_DATA:
                setSourceStatus(3,20,"No data available at this time.");
                break;
            case C_CONNECT_ERROR:
                setSourceStatus(3,21,"QS system error");
                break;
            case C_ALL_DATA:
                caughtUp=true;
                setSourceStatus();
                break;
            case C_NOT_CONNECTED:
                setSourceStatus(3,22,"Not connected to QS data server.");
                break;
            case C_CONNECTING:
                setSourceStatus(3,23,"Getting data");
                break;
            case C_POWER_OFF:
                monitorIsOff=true;
                setSourceStatus();
                //% Returns codes have the wrong time.  It appears to come
                //% from the server, not PMS.  Fudge it here, at least for now.
                //% Too bad we cannot fudge if we have no starting point.
                if (FUDGE_RETURN_CODE_TIME && !neverHadStatus) {
                    long myStartTime=stripChartData.getNewestTime();
                    if (myStartTime!=startTime) {
                        if (TIME_DEBUG) {
                            System.out.println("Fudging time from "+startTime/4+" to "
                                +myStartTime/4+" delta "+(myStartTime-startTime)/4);
                        }
                        startTime=myStartTime;
                    }
                }
                stripChartData.storeMonitorOff(startTime,stripChartData.SAMPLE_RATE,true); // Monitor off comes every sec.
                break;
            case C_PT_ID_CHANGE:
                patientIDChanged=true; // Change the default status returned.
                terminate=true; // End the connection here.
                // Never switch back.
                break;
            default:
                System.err.println("Unknown return code: "+returnCode);
                break;
        }
    }

    /**
     * Checks for and processes an HTTP error message seen in development.
     * <p>
     * I have seen a case during development where instead of the packet was the string
     * <code>
     * <br>
     * "HTTP:/1.1 500 Internal Server Error&lt;cr&gt;&lt;lt&gt;
     * <br>
     * Server: Microsoft-IIS/4.0&lt;cr&gt;&lt;lt&gt;..."
     * </code>
     * <p>
     * Since I am fearful this may happen in the real world, I'll check
     * for that case. If we get here (which should never happen), and the
     * beginning coincides, it must be that crazy message.
     * <p>
     * The error may now be fixed on the server.  Lew turned off MFC header
     * generation, and the problem seemed to go away.
    **/
    boolean webServerError(byte[] buffer) throws IOException{
        if ( buffer[0]=='H' && buffer[1]=='T'
          && buffer[2]=='T' && buffer[3]=='P' ) {
            setSourceStatus(3,25,"Web server error.");
            System.out.println("Error from server:");
            HexDump.dump(buffer);
            String errorText;
            try {
                // Assume JDK 1.1
                errorText=new String(buffer); // JRE 1.1
            } catch (NoSuchMethodError e) {
                errorText=new String(buffer,0); // JRE 1.0 (deprecated)
            }
            byte[] single=new byte[1];
            in.mark(1);
            while (in.read(single)!= -1) {
                char c=(char)single[0];
                if (Character.isISOControl(c) && c!='\r' && c!='\n') {
                    // Binary values.  Probably the end of text
                    in.reset();
                    break;
                }
                in.mark(1);
                errorText+=c;
            }
            System.out.print(errorText);
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Convert a little-endian unsigned 16 bit value. Note that
     * java has no unsigned types.
     *
     * @param buf Array where the two bytes can be found
     * @param offset Which byte numbers will be used.  They will be offset
     * and offset+1.
     *
     * @return The unsigned 16 bit value, in an int (32 bits).  The high order
     * half of the int will be zero.
    **/
    int getCardinal16(byte buf[], int offset) {
        return(((buf[offset+1] & 0xff)<<8) | (buf[offset] & 0xff));
    }

    /**
     * Converts a little-endian signed 32 bit value to an int.
     *
     * @param buf       Source data, as read from a QS system.
     * @param offset    Offset within the <code>buf</code> array.
     *
     * @return The integer value.
    **/
    int getInteger32(byte buf[], int offset) {
        return( ((buf[offset+3] & 0xff)<<24)
              | ((buf[offset+2] & 0xff)<<16)
              | ((buf[offset+1] & 0xff)<<8 )
              | ((buf[offset  ] & 0xff)    ) );
    }

    /**
     *  Gets an enum value with less than 128 choices.
     *
     * @param buf       Source data, as read from a QS system.
     * @param offset    Offset within the <code>buf</code> array.
     *
     * @return The enum value, which will not be less than zero.
    **/
    int getEnum8(byte buf[], int offset) {
        return(buf[offset] & 0xff);
    }

    /**
     *  Gets an unsigned byte (called BYTE in QS code)
     * @param buf       Source data, as read from a QS system.
     * @param offset    Offset within the <code>buf</code> array.
     *
     * @return The byte value, which will not be less than zero.
    **/
    int getByte(byte buf[], int offset) {
        return(buf[offset] & 0xff);
    }

    /**
     * Reads into a buffer, and does not quit until the buffer is full.  The
     * generic InputStream will sometimes return the data in separate <code>read</code>
     * calls.  This method reassembles the pieces and returns the completed result.
     *
     * @param   buf     Destination.
     * @param   n       Number of bytes to read.
     *
     * @exception OutOfDataException    Thrown when the QS system closes the
     *                                  connection.
    **/
    void readIn(byte[] buf, int n) throws IOException,OutOfDataException {
        int nRead=0;
        while (nRead<n && !terminate) {
            int actualRead=in.read(buf,nRead,n-nRead);
            if (actualRead== -1) {
                throw new OutOfDataException();
            }
            nRead+=actualRead;
        }
        if (terminate) {
            throw new InterruptedIOException("ParseQS thread termination");
        }
    }

    /**
     * Skips a number of input bytes.  The generic InputStream may take multiple
     * skip calls to skip all the bytes. (I have not actually seen this phenomenon,
     * but from Chan's description of InputStream.skip(), it is sure possible.
     *
     * @param   buf     Destination.
     * @param   n       Number of bytes to read.
     *
     * @exception OutOfDataException    Thrown when the QS system closes the
     *                                  connection.
    **/
    void skipIn(long n) throws IOException,OutOfDataException {
        long nSkip=0;
        while (nSkip<n && !terminate) {
            // Unfortunately, a bug in Microsoft Internet Explorer generates
            // an exception when you try to use Skip.  From the error message,
            // it looks like they are trying to lseek on a socket, which the
            // socket says it cannot do.  For my purposes, the blocks are small,
            // so I will just read.
            byte[] buf=new byte[(int)Math.min(n-nSkip,1024)];
            long actualSkip=in.read(buf);
            /* Right way: long actualSkip=in.skip(n-nSkip); */
            if (actualSkip== -1) {
                throw new OutOfDataException();
            }
            nSkip+=actualSkip;
        }
        if (terminate) {
            throw new InterruptedIOException("ParseQS thread termination");
        }
    }

    /**
     * Reads the PMS header, and extracts the fields used.  The fields extracted
     * are <code>cBedId, liTime, </code> and <code>eData</code>.
    **/
    void getPMSHeader() throws IOException,OutOfDataException {
        // Read from cAcquireId through eData
        readIn(headerBuf, headerBuf.length);

        // Extract the fields we need.
        cBedId= getCardinal16(headerBuf,BED_ID_OFFSET);
        liTime= getInteger32(headerBuf,TIME_OFFSET);
        eData = getEnum8(headerBuf,EDATA_OFFSET);
        if (DEBUG) {
            System.out.println("Bed id="+cBedId+" liTime="+liTime+" eData="+eData);
        }
    }

    /**
     * Reads in the beginning of wave data.  The only field extracted is the length
     * of the wave data.  The Spectra alert information is ignored.
     * <p>
     * The length of the wave data is returned in <code>cDataLen</code>
    **/
    private void getPMSWaveHeader() throws IOException,OutOfDataException {
        readIn(waveHeader, waveHeader.length);
        // Ignore all the Spectra Alert info (30 bytes)
        cDataLen=getCardinal16(waveHeader,DATA_LEN_OFFSET);
    }

    /**
     * Reads in the wave data, but does no parsing.  The wave data will be
     * in <code>waveData</code>.
     *
     * @param dataLen       Length of wave data expected.  This value comes from
     *                      the header.
    **/
    void getWaveData(int dataLen) throws IOException,OutOfDataException {
        readIn(waveData,dataLen);
    }

    /**
     * Reads in the status data, but does no parsing.  The status data will be in
     * <code>fmStatus</code>.
    **/
    void getFMStatus() throws IOException,OutOfDataException {
        readIn(fmStatus, fmStatus.length);
    }

    /**
     * Process each wave (HR1, HR2, MHR or UA) in the data.
     * <p>
     * The data for all the waves is in the first <code>dataLen</code> bytes of
     * <code>waveData</code>.
     *
     * @param dataLen       Length of the available wave data.
     * @param swapHrs       True (normally), so incoming Hr2 (the primary wave)
     *                      moves to Hr1.  False if MHR is HR2.
    **/
    void storeWaveData(int dataLen, boolean swapHrs) throws BadQSFormatException {
        if (!hasWave) {
            return;
        }
        hasWave=false;
        for (int waveOffset=0; waveOffset+F_WAVE_CHUNK_OFFSET<dataLen; ) {
            int type=waveData[waveOffset];
            int numSamples=getCardinal16(waveData,waveOffset+NUM_SAMPLES_OFFSET);
            waveOffset+=F_WAVE_CHUNK_OFFSET;
            if (waveOffset+numSamples > dataLen) {
                // The data area was not long enough! Bad format.
                HexDump.dump(headerBuf);
                HexDump.dump(waveHeader);
                HexDump.dump(waveData,0,0,dataLen);
                throw (new BadQSFormatException("Insufficient data: "
                    +waveOffset+"+"+numSamples+">"+dataLen+" type="+type));
            }
            if (invokedStandalone) {
                // Debug only: Dump the data to standard output.
                System.out.print("Wave stored:");
                HexDump.dump(waveData,waveOffset,0,numSamples);
            }
            switch (type) {
                // Note the swapping of HR1 and HR2 here. QS uses HR2 as the
                // primary waveform (except if HR2 is MECG).
                case WAVE_FHR1:
                    storeOneWave(waveOffset,
                            swapHrs ? stripChartData.heartRate2 :  stripChartData.heartRate1,
                            HR_PENLIFT,
                            numSamples);
                    break;
                case WAVE_FHR2:
                    storeOneWave(waveOffset,
                            swapHrs ? stripChartData.heartRate1 :  stripChartData.heartRate2,
                            HR_PENLIFT,
                            numSamples);
                    break;
                case WAVE_MHR:
                    storeOneWave(waveOffset,
                            stripChartData.heartRate3,
                            HR_PENLIFT,
                            numSamples);
                    break;
                case WAVE_UA:
                    storeOneWave(waveOffset,
                            stripChartData.uterineActivity,
                            UA_PENLIFT,
                            numSamples);
                    break;
                default:
                    System.err.println("Unknown wave type "+type
                            +" should be 0 to "+N_WAVES);
                    break;
            }
            waveOffset += numSamples;
        }
    }

    /**
     * Copies a single wave's data to internal storage. If needed, the penlift
     * value will change.
     * <p>
     * The incoming data must already be in <code>waveData</code>.  Each sample
     * takes one byte.
     * <p>
     * NOTE: Penlift values in the incoming data will be modified destructively
     * here.
     *
     * @param offset        Index of the start of the wave data within
     *                      <code>waveData</code>
     * @param dest          Destination for the data.
     * @param ourPenlift    Penlift value used in <code>waveData</code>
     * @param nSamples      Number of bytes of dest with data.
    **/
    void storeOneWave(int offset, Waveform dest, byte ourPenlift, int nSamples) {
        // NOTE: Destructive: modifies the penlift values in the waveData buffer.
        // Do we use the same penlift value internally as the incoming data?
        if (ourPenlift != dest.penliftValue) {
            // Switch the penlift value in all the data.
            for (int i=offset; i<offset+nSamples; i++) {
                if (waveData[i]==ourPenlift) {
                    waveData[i] = dest.penliftValue;
                }
            }
        }
        if (DEBUG) {
            System.out.println("ParseQS storing "+nSamples+" samples at "
                + (DEBUG ? dest.getNewestTime() : startTime)
                +"\nliTime="+liTime
                +" SPS="+SAMPLES_PER_SECOND);
        }
        stripChartData.storeWaveform(dest, waveData,offset, nSamples, startTime);
    }

    /**
     * Stores the status and event information from the PMS Status record.
     * The status record must already be in <code>fmStatus</code>, with the time
     * of the record (in quarter second units) in <code>startTime</code>.
     *
     * @param duration How long the status lasted.
     *
    **/
    void storeStatusData(long duration) throws BadQSFormatException {
        if (!hasStatus) {
            return;
        }
        hasStatus=false;
        int statSet   =getEnum8(fmStatus,STAT_SET);
        int chartSpeed=getByte(fmStatus,CHART_SPEED);
        int deviceType=getByte(fmStatus,DEVICE_TYPE);
        int hr1Mode   =getByte(fmStatus,HR1_MODE);
        int hr2Mode   =getByte(fmStatus,HR2_MODE);
        int hr3Mode   =getByte(fmStatus,HR3_MODE);
        int sampleRate=getByte(fmStatus,SAMPLE_RATE);
        int spData    =getByte(fmStatus,SP_DATA);
        int uaMode    =getByte(fmStatus,UA_MODE);
        if (invokedStandalone || STATUS_DEBUG) {
            if (statSet   !=0) System.out.println("statSet= "+statSet);
            if (chartSpeed!=0) System.out.println("chartSpeed="+chartSpeed);
            if (deviceType!=0) System.out.println("deviceType="+deviceType);
            if (hr1Mode   !=0) System.out.println("hr1Mode="+hr1Mode);
            if (hr2Mode   !=0) System.out.println("hr2Mode="+hr2Mode);
            if (hr3Mode   !=0) System.out.println("hr3Mode="+hr3Mode);
            if (sampleRate!=0) System.out.println("sampleRate="+sampleRate);
            if (spData    !=0) System.out.println("spData="+spData);
            if (uaMode    !=0) System.out.println("uaMode="+uaMode);
        }
        boolean monitorOff= (statSet & FM_STAT_POWER_OFF)!=0;
        boolean monitorOn = (statSet & FM_STAT_POWER_ON )!=0;
        boolean bufferOverflow= (statSet & FM_STAT_BUFFER_OVERFLOW)!=0;
        if (STATUS_DEBUG || MONITOR_OFF_DEBUG) { //% Debug
            if (monitorOff) System.out.println("Monitor Off "+startTime/4);
            if (monitorOn)  System.out.println("Monitor On  "+startTime/4);
        }

        // Modes
        // The QS system puts the primary waveform into HR2.  The secondary waveform
        // is in HR1.  The one exception is when HR2 is MECG.  Here, and in the
        // waveform, we swap the two channels.  Fortunately, the status always
        // comes before the data.
        // NEWS FLASH! Even that is not right.  HR3 waveform is really MHR, but
        // the mode might be in HR1 or HR2.  Put the MECG mode
        // into hr3 to agree with the waveform.
        HrMode hr1ModeValue=translateHrMode(hr1Mode);
        HrMode hr2ModeValue=translateHrMode(hr2Mode);

        if (MODE_DEBUG || STATUS_DEBUG) {  //% Debug
            System.out.println(hr1ModeValue.toString()+" "
                              +hr2ModeValue.toString()+" "
                              +translateHrMode(hr3Mode).toString()+" "+startTime/4);
        }
        if ( hr1Mode==0 && hr2Mode==0 && hr3Mode==0
          && (monitorOff || monitorOn || bufferOverflow || spData!=0) ) {
            // Do not store the modes. They are not valid.
        }
        else if (hr2ModeValue.isMaternal()) {
            // Maternal alone.
            swapHeartRates=false;
            storeHrMode(stripChartData.hr1Modes, hr1ModeValue,  duration);
            storeHrMode(stripChartData.hr2Modes, HrMode.INOP,   duration);
            storeHrMode(stripChartData.hr3Modes, hr2ModeValue,  duration);
        }
        else if (hr1ModeValue.isMaternal()) {
            // Maternal and fetal.
            swapHeartRates=true;
            storeHrMode(stripChartData.hr1Modes, hr2ModeValue,  duration);
            storeHrMode(stripChartData.hr2Modes, HrMode.INOP,   duration);
            storeHrMode(stripChartData.hr3Modes, hr1ModeValue,  duration);
        }
        else {
            swapHeartRates=true;
            // Translate US US to US US2
            if (hr1ModeValue==HrMode.US && hr2ModeValue==HrMode.US) {
                hr1ModeValue=HrMode.US2;
            }
            HrMode hr3ModeValue=translateHrMode(hr3Mode);
            storeHrMode(stripChartData.hr1Modes, hr2ModeValue,  duration);
            storeHrMode(stripChartData.hr2Modes, hr1ModeValue,  duration);
            storeHrMode(stripChartData.hr3Modes, hr3ModeValue,  duration);
        }
        if ( uaMode==0
          && (monitorOff || monitorOn || bufferOverflow || spData!=0) ) {
            // Do not store the mode. It is not valid.
        }
        else {
            storeUaMode(uaMode,duration);
        }

        // Event marks
        if ((spData & FM_STAT_SP_DATA_MARK)!=0) {
            stripChartData.storeMark(startTime,EventMarkType.MARK);
        }
        if ( (spData & FM_STAT_SP_DATA_BP)!=0
          || (spData & FM_STAT_SP_DATA_SPO2)!=0 ) {
            stripChartData.storeMark(startTime,EventMarkType.DIAMOND);
        }
        if ((spData & FM_STAT_SP_DATA_FAST)!=0) {
            stripChartData.storeMark(startTime,EventMarkType.FAST);
        }

        // Monitor on/off
        if (monitorOn) {
            monitorIsOff=false;
            stripChartData.storeMonitorOff(startTime,duration,false);
        }
        else if (monitorOff) {
            monitorIsOff=true;
            stripChartData.storeMonitorOff(startTime,duration,true);
        }

        neverHadStatus=false;
    }

    /**
     * Converts a heart rate mode from QS format, and stores it.  Unknown mode
     * value are converted to <code>null</code>.
     *
     * @param tank      Destination.
     * @param qsMode    Mode value from the QS system.
    **/
    private void storeHrMode(StatusTank tank, HrMode mode, long duration) {
        stripChartData.storeHrMode(tank,startTime,duration,mode);
    }

    /**
     * Converts a heart rate mode from QS format, and stores it.  Unknown mode
     * value are converted to <code>null</code>.
     *
     * @param tank      Destination.
     * @param qsMode    Mode value from the QS system.
    **/
    private HrMode translateHrMode(int qsMode) {
        switch (qsMode) {
            case FM_STAT_MODE_FECG:   return HrMode.FECG;
            case FM_STAT_MODE_EXT:    return HrMode.US;
            case FM_STAT_MODE_MAECG:  return HrMode.MAECG;
            case FM_STAT_MODE_MECG:   return HrMode.MECG;
            case FM_STAT_MODE_EXT_MHR:return HrMode.EXT_MHR;
            // OFF and NO TRANS are a competitor's name for INOP.
            case FM_STAT_MODE_NO_TRANS:
            case FM_STAT_MODE_OFF:
            case FM_STAT_MODE_INOP:   return HrMode.INOP;
            case FM_STAT_MODE_PHONO:  return HrMode.PHONO;
            case FM_STAT_MODE_UNDEFINED:
            case FM_STAT_MODE_UNKNOWN:return HrMode.UNKNOWN;
            default:
                System.err.println("Unknown HR mode value "+qsMode);
                                      return HrMode.UNKNOWN;
        }
    }

    /**
     * Converts a uterine activity mode from QS format, and stores it.  Unknown mode
     * value are converted to <code>null</code>.
     *
     * @param qsMode    Mode value from the QS system.
    **/
    private void storeUaMode(int qsMode, long duration) {
        switch (qsMode) {
            case FM_STAT_MODE_TOCO:   stripChartData.storeUaMode(startTime,duration,UaMode.TOCO);  break;
            case FM_STAT_MODE_IUP:    stripChartData.storeUaMode(startTime,duration,UaMode.IUP );  break;
            case FM_STAT_MODE_NO_TRANS:
            case FM_STAT_MODE_OFF:
            case FM_STAT_MODE_INOP:   stripChartData.storeUaMode(startTime,duration,UaMode.INOP);  break;
            case FM_STAT_MODE_UNDEFINED:
            case FM_STAT_MODE_UNKNOWN:stripChartData.storeUaMode(startTime,duration,UaMode.UNKNOWN);break;
            default:
                System.err.println("Unknown UA mode value "+qsMode);
                                      stripChartData.storeUaMode(startTime,duration,UaMode.UNKNOWN);break;
        }
    }

    /**
     * Convert from QS time to quarter seconds.  More accurately, we use
     * "Quarter second samples since the first data received by this module."
     * <p>
     * The QS system synchronizes with the monitor at the start of monitoring.
     * From that point, the monitor's sample rate drives time.
     * <p>
     * <bold>CAUTION:</bold>
     * This is a comment from the QS code: <br><i>
     *              NOTE that while the base year is 1976, a coded time of zero
     *              is really (if it were legal, which it isn't!) midnight on
     *              12/31/75.  This little known fact becomes important when
     *              converting QS coded times to some other system's coded times
     *              using addition/subtraction.
     * </i><br>
     *
     * <p>
     * The returned times are offset from Java GMT by the QS system's local time
     * offset.  Thus if one converts the returned value to a date (new Date(...*250))
     * and print it as GMT, the result will be local QS time.
     *
     * @param inTime    Time, in QS units, which are seconds from Jan 1970
     * @return Quarter seconds since we started getting data.
    **/
    long convertTimeUnits(long inTime) {
        return inTime*SAMPLES_PER_SECOND+QS_TO_JAVA_SAMPLES
                +stripChartData.daylightTimeOffset;
    }

    public long toQSTime(long time) {
        return (time-stripChartData.daylightTimeOffset-QS_TO_JAVA_SAMPLES)/SAMPLES_PER_SECOND;
    }

    /**
     * Returns the current status, or null if ok.
    **/
    public synchronized String getStatus() {
        if (patientIDChanged) {
            return "Patient ID changed.  Possibly a new patient";
        }
        if (hasSourceStatus) {
            return hasContent ? sourceStatus1+sourceStatus2+sourceStatus3 : sourceStatus1;
        }
        if (monitorIsOff) {
            return "Fetal monitor is off";
        }
        return null;
    }

    /**
     * Returns the current status, or null if ok.  Translations are looked up
     * in the given message table.
    **/
    public synchronized String getStatus(UserMessageTable table) {
        if (table==null) {
            return getStatus();
        }
        if (patientIDChanged) {
            return table.getTranslation(3,24,"Patient ID changed.  Possibly a new patient");
        }
        if (hasSourceStatus) {
            if (hasContent) {
                return table.getTranslation(dialog,messageID,sourceStatus1)
                      +sourceStatus2
                      +table.getTranslation(dialog,messageID+1,sourceStatus3);
            }
            else {
                return table.getTranslation(dialog,messageID,sourceStatus1);
            }
        }
        if (monitorIsOff) {
            return table.getTranslation(3,31,"Fetal monitor is off");
        }
        return null;
    }

    /**
     * Assigns the current status to null, for ok.
    **/
    synchronized void setSourceStatus() {
        hasSourceStatus=false;
        sourceStatus1=null;
        sourceStatus2=null;
        sourceStatus3=null;
        hasContent=false;
        dialog=0;
        messageID=0;
    }

    /**
     * Assigns the current status.
    **/
    synchronized void setSourceStatus(int dialog, int messageID,String status) {
        sourceStatus1=status;
        sourceStatus2=null;
        sourceStatus3=null;
        hasContent=false;
        this.dialog=dialog;
        this.messageID=messageID;
        hasSourceStatus=true;
    }

    /**
     * Assigns the current status.  Use a status of null for ok.
    **/
    synchronized void setSourceStatus(int dialog, int messageID,String status1,
                        Object obj,String status3) {
        sourceStatus1=status1;
        sourceStatus2=obj.toString();
        sourceStatus3=status3;
        hasContent=true;
        this.dialog=dialog;
        this.messageID=messageID;
        hasSourceStatus=true;
    }

    /**
     * Decides if PMS has returned its entire history.  At first, PMS empties
     * its history buffer of up to 50 minutes.  Eventually it catches up to
     * real time.
     *
     * @return True after PMS switches to real time.
    **/
    public boolean isCaughtUp() {
        return caughtUp;
    }
}

