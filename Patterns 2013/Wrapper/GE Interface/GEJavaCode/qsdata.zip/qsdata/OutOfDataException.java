
//Title:        OutOfDataException
//Version:      9/24/99
//Copyright:    Copyright (c) 1999 GE Marquette Medical Systems
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet


package com.mei.coro.qsdata;

/**
 * Exception raised when we get End of File on the PMS data input.
 * Since the data is real-time, it should never end.
 */
class OutOfDataException extends Exception {
    OutOfDataException() {}
}

