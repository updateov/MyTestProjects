
//Title:        BadQSFormatException
//Version:      9/24/99
//Copyright:    Copyright (c) 1999 GE Marquette Medical Systems
//Author:       Andy Pelletier
//Company:      GEMMS/Wallingford
//Description:  Display QS waveforms in an applet


package com.mei.coro.qsdata;

/**
 * Exception raised when data does not match the PMS format.
 */
class BadQSFormatException extends Exception {
    BadQSFormatException() {}

    BadQSFormatException(String msg) {
        super(msg);
    }
}

