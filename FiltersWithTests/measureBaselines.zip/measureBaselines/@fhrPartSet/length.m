%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   function @fhrPartSet/length
%
%   Description:    
%	   returns the length of the set
%
%	 Parameters:
%       this              (fhrPartSet)  
%
%   Returns:
%       nElements         (double)
%
%	 $Revision $
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function nElements = length(this)
nElements = length(this.set);
return

