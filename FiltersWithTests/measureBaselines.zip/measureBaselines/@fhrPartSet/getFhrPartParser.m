function pp = getFhrPartParser(this)

    pp = this.fhrPartParser;
    
return;