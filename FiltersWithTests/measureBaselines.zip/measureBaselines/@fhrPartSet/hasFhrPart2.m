function b = hasFhrPart2(this)

    b = isa(getFhrPartParser(this), 'fhrPartParser2');
    
return;