%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   function @fhrPartSet/getRawData
%
%   Description:    
%	   returns the raw set.  Should only be used by fhrPartSet methods such
%      as add()?
%
%	 Parameters:
%       this              (fhrPartSet)  
%
%   Returns:
%       set               (set of fhrParts)
%
%	 $Revision $
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function set = getRawData(this)
set = this.set;
return

