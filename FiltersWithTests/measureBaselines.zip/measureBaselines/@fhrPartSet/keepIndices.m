function this = keepIndices(this, keep)

    this.set = this.set(keep);
    
return;