function this = setDocking(this, doDocking)
if nargin < 2
    doDocking = true;
end

this.doDocking = doDocking;
return
