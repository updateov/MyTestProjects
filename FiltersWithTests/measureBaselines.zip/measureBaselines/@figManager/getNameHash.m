function hash = getNameHash(this)
hash = this.nameHash;
return
