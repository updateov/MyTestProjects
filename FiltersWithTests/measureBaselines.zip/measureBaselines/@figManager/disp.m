function this = disp(this)
disp(this.nameHash);
return