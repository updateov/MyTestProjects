function this = setDocked(this, doDocked)
this.doDocked = true;
return
