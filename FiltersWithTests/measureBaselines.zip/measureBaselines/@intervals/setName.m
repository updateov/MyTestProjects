%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   function @intervals/setName
%
%   Description:    
%	   returns the name of intervals
%
%	 Parameters:
%	    this 	          (intervals) 
%	    name 	          (char) 
% 
%   Returns:
%       this              (intervals)
%	 $Revision $
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function this = setName(this, name)
this.name = name;
return